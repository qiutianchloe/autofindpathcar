<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="traps" tilewidth="32" tileheight="32" tilecount="192" columns="16">
 <image source="traps.png" width="512" height="384"/>
 <tile id="0">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="type" value="WaterTrap"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="type" value="WaterTrap"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="type" value="WaterTrap"/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="type" value="WaterTrap"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="type" value="WaterTrap"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="type" value="WaterTrap"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="type" value="HealthTrap"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="type" value="HealthTrap"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="type" value="HealthTrap"/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="type" value="HealthTrap"/>
  </properties>
 </tile>
 <tile id="77">
  <properties>
   <property name="type" value="HealthTrap"/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="87">
  <properties>
   <property name="type" value="GrassTrap"/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="type" value="HealthTrap"/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="type" value="HealthTrap"/>
  </properties>
 </tile>
 <tile id="144">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="148">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="149">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="152">
  <properties>
   <property name="type" value="ParcelTrap"/>
  </properties>
 </tile>
 <tile id="153">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="154">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="155">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="156">
  <properties>
   <property name="key" type="int" value="1"/>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="157">
  <properties>
   <property name="key" type="int" value="2"/>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="158">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="159">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="162">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="163">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="164">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="168">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="169">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="170">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="171">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="172">
  <properties>
   <property name="key" type="int" value="3"/>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="173">
  <properties>
   <property name="key" type="int" value="4"/>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="174">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="175">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="176">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="177">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="178">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="180">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="type" value="MudTrap"/>
  </properties>
 </tile>
 <tile id="184">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="185">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="187">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="188">
  <properties>
   <property name="key" type="int" value="5"/>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="189">
  <properties>
   <property name="key" type="int" value="6"/>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="190">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
 <tile id="191">
  <properties>
   <property name="type" value="LavaTrap"/>
  </properties>
 </tile>
</tileset>
